JUICEFALL PRESS KIT

Juicefall is a falling-jelly puzzle for iPhone where you match colors, not rows.

Jelly shapes drop into a narrow well. Line up three or more jellies of one color, in a row or a column, and they burst; whatever falls after can match again, and every step of a cascade multiplies the points. Full rows do nothing. A swap meter banks up to three swaps, and some matches make fruit with a job. Wild, Calm and Hectic, Quirky Play (a 90-second game with a new quirk each day) and the tutorials are free to play, with ads between games; one purchase, the Full Game, removes the ads and adds six fruits. No subscription and no account.

FACT SHEET
Game: Juicefall (on the App Store: Juicefall: Jelly Match Puzzle)
Developer: Aaron Seaman
Platform: iPhone, iOS 26 or later
Genre: Puzzle (falling shapes, matched by color)
Price: Free, with ads; the Full Game, one in-app purchase (US$2.99 in the United States), removes the ads and adds six fruits
Ads and subscription: ads between games and after a game without the Full Game, limited to general-audience content; no subscription
Privacy: the game itself sends nothing to the developer; without the Full Game, Google AdMob collects data for its ads, with consent where the law requires it, and the game asks once for permission to track; plays offline
Languages: English, French, German, Japanese, Portuguese (Brazil), Spanish
Age rating: 4+
Release: November 2026
App Store: coming November 2026 (https://apps.apple.com/app/id6823235878 from release day)
Website: https://juicefall.com/
Press page: https://juicefall.com/press.html

IN THIS FOLDER
screenshots/  the eight App Store pictures, 1320 x 2868: the game captured on the iPhone simulator; some boards were set up with a developer tool
icon/         juicefall-icon-1024.png

Everything here may be used in coverage of Juicefall. Please show the pictures and the icon whole, without stretching or recoloring.
