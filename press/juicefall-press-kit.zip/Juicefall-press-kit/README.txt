JUICEFALL PRESS KIT

Juicefall is a falling-jelly puzzle for iPhone where you match colors, not rows.

Jelly shapes drop into a garden well. Line up three or more jellies of one color, in a row or a column, and they burst into juice; whatever falls after can match again, and every step of a cascade multiplies the points. Full rows do nothing. Bigger matches make fruit with a job, from a blueberry that clears its row to grapes that take a whole color. Free to play, with no ads, no subscription and no account.

FACT SHEET
Game: Juicefall (on the App Store: Juicefall: Jelly Match Puzzle)
Developer: Aaron Seaman
Platform: iPhone, iOS 26 or later
Genre: Puzzle (falling shapes, matched by color)
Price: Free; six fruit as optional one-time purchases (US$0.99 to US$1.99 each, or all six for US$5.99)
Ads and subscription: none
Privacy: Data Not Collected; no account; plays offline
Languages: English, French, German, Japanese, Portuguese (Brazil), Spanish
Age rating: 4+
App Store: https://apps.apple.com/app/id6823235878
Website: https://aaronseaman.github.io/juicefall/
Press page: https://aaronseaman.github.io/juicefall/press.html

IN THIS FOLDER
screenshots/  eight screenshots, 1320 x 2868
art/          juicefall-logo.png (clear background), juicefall-icon-1024.png, key art at 3840 pixels wide
video/        juicefall-preview.mp4, 18 seconds of play

Everything here may be used in coverage of Juicefall. Please show the logo and art whole, without stretching or recoloring.
